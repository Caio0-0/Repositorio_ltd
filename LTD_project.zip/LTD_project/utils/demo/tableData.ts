interface ITableData{
  
  name: string
  amount: number

 
}


const tableData: ITableData[] =  [
  {
  
    name: 'Chandler Jacobi',

    amount: 989.4,
  
  
  },
  {
   
    name: 'Monserrat Marquardt',

    amount: 471.44,
    
    
  },
  {
   
    name: 'Lonie Wyman',
    amount: 934.24,
   
  },
  {
   
    name: 'Corine Abernathy',
 
    amount: 351.28,

  },
  {
 
    name: 'Lorenz Botsford',

    amount: 355.3,
   
  },
  {

    name: 'Everette Botsford',
  
    amount: 525.42,
    
   
  },
  {
    name: 'Marilou Beahan',
    amount: 414.99,
  },
  {
    name: 'Ceasar Sauer',
    amount: 488.0,
    
  },
  {
    
    name: 'Rae McDermott',

    amount: 502.69,
  
  },
  {
    name: 'Mable Steuber',
    amount: 911.09,
  },

]

export default tableData
export type {
  ITableData
}
